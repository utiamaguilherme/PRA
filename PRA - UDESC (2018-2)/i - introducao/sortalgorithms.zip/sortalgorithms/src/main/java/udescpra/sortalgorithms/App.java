package udescpra.sortalgorithms;

/**
 * Introdução aos Algoritmos de ordenação usando Java
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
    }
}
