package edu.udesc.procura.view;

/**
 *
 * @author udesc
 */
public class MainController {
    
}
