package edu.udesc.procura.search;

/**
 *
 * @author udesc
 */
public interface ISearchStrategy {
    /**
     * Inserido no Java 8
     * @param text
     * @param word 
     */
    public default void prepareSearch(String text, String word) {
    }
    public abstract WordLocation search();
}
