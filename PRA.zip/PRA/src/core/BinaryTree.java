package core;

import java.util.TreeSet;


public class BinaryTree<T extends Comparable> extends TreeSet<T>{
    
	
	
}
