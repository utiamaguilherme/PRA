package core;

import java.util.Iterator;
import java.util.TreeSet;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.stream.Stream;

public class CopyOfBinaryTree<T extends Comparable> extends TreeSet<T>{
    
	
	
}
