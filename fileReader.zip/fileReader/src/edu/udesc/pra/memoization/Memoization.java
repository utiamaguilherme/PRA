package edu.udesc.pra.memoization;

public class Memoization {
// https://dzone.com/articles/java-8-automatic-memoization
// https://opencredo.com/lambda-memoization-in-java-8/
// http://bendra.github.io/java/lambda/functional/memoization/guava/2014/12/08/functional-programing-memoziation-java-8.html
// https://crunchify.com/how-to-create-a-simple-in-memory-cache-in-java-lightweight-cache/
	
}
