/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.edu.udesc.business;

import br.edu.udesc.exceptions.InputException;
import br.edu.udesc.exceptions.NegativeValueEnteredException;
import java.math.BigInteger;

/**
 *
 * @author udesc
 */
public class SuperFatorial implements ISuperFatorial {

    @Override
    public BigInteger getSuperFatorial(BigInteger numero) throws InputException {
        if(numero.compareTo(BigInteger.ZERO) < 0){
            throw new NegativeValueEnteredException("Numero invalido inserido");
        }
        if(numero.compareTo(BigInteger.ZERO) == 0){
            return BigInteger.ONE;
        }
        return Calcula(numero, BigInteger.ONE);
    }
    
    private BigInteger Calcula(BigInteger numero, BigInteger i){
        System.out.println(numero.compareTo(i));
        if(numero.compareTo(i) <= 0) return BigInteger.ONE;
        return Calcula(numero, i.add(BigInteger.ONE)).multiply((numero.subtract(i).add(BigInteger.ONE)).pow(i.intValueExact()));
//        return Calcula(numero, i.add(BigInteger.ONE)).multiply(numero.subtract(i).add(BigInteger.ONE)).pow(i.intValueExact());
    }
    
}
